from mdp_simulator.utils.enums import Topics
from mdp_simulator.utils.pub_sub import PubSub

Context: PubSub = PubSub(Topics)
